import tkinter as tk
import csv
from tkinter import messagebox

# Save Data
def save_expense():
    amount = amount_entry.get()
    category = category_entry.get()
    note = note_entry.get()

    # Validate amount
    try:
        amount = float(amount)
    except ValueError:
        messagebox.showerror("Error", "Amount must be a number")
        return

    if category.strip() == "":
        messagebox.showerror("Error", "Enter category")
        return

    with open("expenses3.csv", "a", newline="") as file:
        writer = csv.writer(file)
        writer.writerow([amount, category, note])

    amount_entry.delete(0, tk.END)
    category_entry.delete(0, tk.END)
    note_entry.delete(0, tk.END)

    messagebox.showinfo("Saved", "Expense Added!")

# Load Data
def load_data():
    data = []
    try:
        with open("expenses3.csv", "r") as file:
            reader = csv.reader(file)
            for row in reader:
                if row and row[0].strip():  # skip empty rows
                    data.append(row)
    except FileNotFoundError:
        pass
    return data

# Recursion Function
def recursive_total(data, index=0):
    if index == len(data):
        return 0
    try:
        return float(data[index][0]) + recursive_total(data, index + 1)
    except ValueError:
        return recursive_total(data, index + 1)  # skip bad rows

# Show Summary
def show_summary():
    data = load_data()

    if not data:
        messagebox.showinfo("Info", "No data found")
        return

    total = recursive_total(data)

    category_dict = {}
    for row in data:
        try:
            amount = float(row[0])
            category = row[1]
            category_dict[category] = category_dict.get(category, 0) + amount
        except (ValueError, IndexError):
            continue

    result = f"Total Expenses: {total}\n\nCategory Summary:\n"
    for cat, amt in category_dict.items():
        result += f"{cat}: {amt}\n"

    messagebox.showinfo("Summary", result)

# GUI
root = tk.Tk()
root.title("Expense Tracker")

tk.Label(root, text="Amount").grid(row=0, column=0)
tk.Label(root, text="Category").grid(row=1, column=0)
tk.Label(root, text="Note").grid(row=2, column=0)

amount_entry = tk.Entry(root)
category_entry = tk.Entry(root)
note_entry = tk.Entry(root)

amount_entry.grid(row=0, column=1)
category_entry.grid(row=1, column=1)
note_entry.grid(row=2, column=1)

tk.Button(root, text="Add Expense", command=save_expense).grid(row=3, column=0)
tk.Button(root, text="Show Summary", command=show_summary).grid(row=3, column=1)

root.mainloop()