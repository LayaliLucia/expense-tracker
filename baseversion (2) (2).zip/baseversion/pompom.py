import os, csv, tkinter as tk
from datetime import datetime
from tkinter import ttk, messagebox
import customtkinter as ctk
from PIL import Image, ImageTk, ImageSequence
from matplotlib import font_manager, rcParams
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

# Font Setup
FONT_FILENAME = "Jersey10-Regular.ttf"
if os.path.exists(FONT_FILENAME):
    font_manager.fontManager.addfont(os.path.abspath(FONT_FILENAME))
    FONT_FAMILY = font_manager.FontProperties(fname=FONT_FILENAME).get_name()
    rcParams["font.family"] = FONT_FAMILY
else:
    FONT_FAMILY = "Verdana"  # Simple fallback if font file is missing

# Constants 
BG, PANEL, CARD = "#efe6dd", "#e8dfd2", "#f7f3ef"
BRIGHT_BROWN, YELLOW = "#7B3F00", "#c9b037"
CSV_FILE = "expenses.csv"
GIF_FILES = ["run.gif", "food.gif", "q.gif", "spent.gif"]

# Database Helpers
def ensure_csv():
    if not os.path.exists(CSV_FILE):
        with open(CSV_FILE, "w", newline="") as f:
            csv.DictWriter(f, fieldnames=["id","date","desc","cat","amount","type"]).writeheader()

def load_rows():
    if not os.path.exists(CSV_FILE): return []
    with open(CSV_FILE, newline="") as f:
        return [{**r, "amount": float(r["amount"] or 0.0)} for r in csv.DictReader(f)]

def save_rows(rows):
    with open(CSV_FILE, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["id","date","desc","cat","amount","type"])
        w.writeheader()
        w.writerows(rows)

# Application
class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        ensure_csv()
        ctk.set_appearance_mode("light")
        self.title("Expense Tracker")
        self.geometry("1200://800")
        self.configure(fg_color=BG)

        # Fonts
        self.title_font = (FONT_FAMILY, 28, "bold")
        self.heading_font = (FONT_FAMILY, 18, "bold")
        self.widget_font = (FONT_FAMILY, 14)
        rcParams["font.size"] = 12

        # Load GIFs cleanly
        self.framesets = []
        for fn in GIF_FILES:
            if os.path.exists(fn):
                img = Image.open(fn)
                frames = [ImageTk.PhotoImage(f.convert("RGBA").resize((70, 70), Image.Resampling.LANCZOS)) for f in ImageSequence.Iterator(img)]
                if frames: self.framesets.append(frames)
        
        self.anim_idx = 0
        self.build_ui()
        self.animate_gifs()
        self.refresh()

    def build_ui(self):
        # Header Section
        header = ctk.CTkFrame(self, fg_color=PANEL, height=100)
        header.pack(fill="x", padx=10, pady=5)
        
        ctk.CTkLabel(header, text="EXPENSE TRACKER", font=self.title_font, text_color=BRIGHT_BROWN).pack(side="left", padx=20)
        
        # Simple Container for GIFs
        self.gif_container = tk.Frame(header, bg=PANEL)
        self.gif_container.pack(side="right", padx=20)
        self.gif_labels = []
        
        for i in range(len(self.framesets)):
            lbl = tk.Label(self.gif_container, bg=PANEL)
            lbl.pack(side="left", padx=5)
            self.gif_labels.append((lbl, i))

        # Control Buttons
        btns = ctk.CTkFrame(self, fg_color="transparent")
        btns.pack(fill="x", padx=10, pady=5)
        ctk.CTkButton(btns, text="➕ ADD", font=self.heading_font, fg_color=BRIGHT_BROWN, command=lambda: self.open_form(None)).pack(side="left", padx=5)
        ctk.CTkButton(btns, text="✎ EDIT", font=self.heading_font, fg_color=PANEL, text_color=BRIGHT_BROWN, command=self.edit_selected).pack(side="left", padx=5)
        ctk.CTkButton(btns, text="🗑 DELETE", font=self.heading_font, fg_color="#b85a3a", command=self.delete_selected).pack(side="left", padx=5)

        # Summary Cards
        totals = ctk.CTkFrame(self, fg_color=CARD)
        totals.pack(fill="x", padx=10, pady=5)
        self.lbl_exp = ctk.CTkLabel(totals, text="EXPENSES\n$0.00", font=self.heading_font, text_color=BRIGHT_BROWN)
        self.lbl_bal = ctk.CTkLabel(totals, text="BALANCE\n$0.00", font=self.heading_font, text_color=BRIGHT_BROWN)
        self.lbl_inc = ctk.CTkLabel(totals, text="INCOME\n$0.00", font=self.heading_font, text_color=BRIGHT_BROWN)
        self.lbl_exp.pack(side="left", expand=True, pady=10)
        self.lbl_bal.pack(side="left", expand=True, pady=10)
        self.lbl_inc.pack(side="left", expand=True, pady=10)

        # Main Layout (Split View)
        main = ctk.CTkFrame(self, fg_color="transparent")
        main.pack(fill="both", expand=True, padx=10, pady=5)

        # Left Column: Table
        left = ctk.CTkFrame(main, fg_color=CARD)
        left.pack(side="left", fill="both", expand=True, padx=(0, 5))
        
        style = ttk.Style()
        style.configure("Treeview", font=self.widget_font, rowheight=30)
        style.configure("Treeview.Heading", font=(FONT_FAMILY, 12, "bold"))
        
        cols = ("date", "desc", "cat", "amount", "type")
        self.tree = ttk.Treeview(left, columns=cols, show="headings")
        for c in cols: 
            self.tree.heading(c, text=c.upper())
            self.tree.column(c, width=100)
        self.tree.pack(fill="both", expand=True, padx=5, pady=5)

        # Right Column: Charts
        right = ctk.CTkFrame(main, fg_color=CARD)
        right.pack(side="right", fill="both", expand=True, padx=(5, 0))
        
        self.bar_fig = Figure(facecolor=PANEL, figsize=(5, 3.5))
        self.bar_ax = self.bar_fig.add_subplot(111)
        self.bar_cv = FigureCanvasTkAgg(self.bar_fig, master=right)
        self.bar_cv.get_tk_widget().pack(fill="both", expand=True, pady=5)

        self.pie_fig = Figure(facecolor=PANEL, figsize=(5, 3.5))
        self.pie_ax = self.pie_fig.add_subplot(111)
        self.pie_cv = FigureCanvasTkAgg(self.pie_fig, master=right)
        self.pie_cv.get_tk_widget().pack(fill="both", expand=True, pady=5)

    def animate_gifs(self):
        if self.framesets:
            for lbl, fs_idx in self.gif_labels:
                fs = self.framesets[fs_idx]
                frame = fs[self.anim_idx % len(fs)]
                lbl.configure(image=frame)
                lbl.image = frame  # Keep reference from garbage collector
            self.anim_idx += 1
        self.after(100, self.animate_gifs)

    def refresh(self):
        rows = load_rows()
        self.tree.delete(*self.tree.get_children())
        for r in sorted(rows, key=lambda x: x.get("date", ""), reverse=True):
            self.tree.insert("", "end", iid=r["id"], values=(r["date"], r["desc"], r["cat"], f"${r['amount']:,.2f}", r["type"]))
        
        inc = sum(r["amount"] for r in rows if r["type"] == "Income")
        exp = sum(r["amount"] for r in rows if r["type"] == "Expense")
        
        self.lbl_exp.configure(text=f"TOTAL EXPENSES\n${exp:,.2f}")
        self.lbl_inc.configure(text=f"TOTAL INCOME\n${inc:,.2f}")
        self.lbl_bal.configure(text=f"BALANCE\n${(inc - exp):,.2f}")
        
        self.update_charts(rows)

    def open_form(self, record):
        is_edit = record is not None
        pop = ctk.CTkToplevel(self)
        pop.title("Form")
        pop.geometry("400x450")
        pop.grab_set()

        def make_entry(lbl_text, default_val=""):
            ctk.CTkLabel(pop, text=lbl_text, font=self.widget_font, text_color=BRIGHT_BROWN).pack(anchor="w", padx=20, pady=(5, 0))
            e = ctk.CTkEntry(pop, fg_color=PANEL, text_color=BRIGHT_BROWN, font=self.widget_font)
            e.pack(fill="x", padx=20)
            e.insert(0, str(default_val))
            return e

        e_desc = make_entry("Description:", record.get("desc", "") if is_edit else "")
        e_amt = make_entry("Amount ($):", record.get("amount", "") if is_edit else "")
        e_date = make_entry("Date (YYYY-MM-DD):", record.get("date", datetime.now().strftime("%Y-%m-%d")) if is_edit else datetime.now().strftime("%Y-%m-%d"))

        ctk.CTkLabel(pop, text="Category:", font=self.widget_font, text_color=BRIGHT_BROWN).pack(anchor="w", padx=20, pady=5)
        e_cat = ctk.CTkComboBox(pop, values=["Food", "Transport", "Housing", "Health", "Entertainment", "Shopping", "Other"], font=self.widget_font, fg_color=PANEL, text_color=BRIGHT_BROWN)
        e_cat.pack(fill="x", padx=20)
        if is_edit: e_cat.set(record.get("cat", "Other"))

        v_type = tk.StringVar(value=record.get("type", "Expense") if is_edit else "Expense")
        rb_frame = ctk.CTkFrame(pop, fg_color="transparent")
        rb_frame.pack(pady=10)
        ctk.CTkRadioButton(rb_frame, text="Expense", variable=v_type, value="Expense", font=self.widget_font, text_color=BRIGHT_BROWN).pack(side="left", padx=10)
        ctk.CTkRadioButton(rb_frame, text="Income", variable=v_type, value="Income", font=self.widget_font, text_color=BRIGHT_BROWN).pack(side="left", padx=10)

        def save():
            if not e_desc.get().strip() or not e_amt.get().strip():
                messagebox.showerror("Error", "All fields required."); return
            try:
                amt = float(e_amt.get().strip())
            except ValueError:
                messagebox.showerror("Error", "Invalid amount."); return

            rec = {"id": record["id"] if is_edit else datetime.now().strftime("%Y%m%d%H%M%S"),
                   "date": e_date.get().strip(), "desc": e_desc.get().strip(), "cat": e_cat.get(), "amount": amt, "type": v_type.get()}
            
            rows = load_rows()
            rows = [rec if r["id"] == rec["id"] else r for r in rows] if is_edit else rows + [rec]
            save_rows(rows)
            pop.destroy()
            self.refresh()

        ctk.CTkButton(pop, text="SAVE", font=self.heading_font, fg_color=BRIGHT_BROWN, command=save).pack(pady=15)

    def edit_selected(self):
        sel = self.tree.selection()
        if not sel: messagebox.showinfo("Info", "Select a row first."); return
        rec = next((r for r in load_rows() if r["id"] == sel[0]), None)
        if rec: self.open_form(rec)

    def delete_selected(self):
        sel = self.tree.selection()
        if not sel: messagebox.showinfo("Info", "Select a row first."); return
        if messagebox.askyesno("Confirm", "Delete transaction?"):
            save_rows([r for r in load_rows() if r["id"] != sel[0]])
            self.refresh()

    def update_charts(self, rows):
        # Update Bar Chart
        self.bar_ax.clear()
        self.bar_ax.set_facecolor(PANEL)
        data = {}
        for r in rows:
            m = r["date"][:7]
            if m not in data: data[m] = {"Income": 0.0, "Expense": 0.0}
            data[m][r["type"]] += r["amount"]
        
        months = sorted(data.keys())
        if months:
            x = range(len(months))
            self.bar_ax.bar([i - 0.2 for i in x], [data[m]["Expense"] for m in months], width=0.4, color=BRIGHT_BROWN, label="Exp")
            self.bar_ax.bar([i + 0.2 for i in x], [data[m]["Income"] for m in months], width=0.4, color=YELLOW, label="Inc")
            self.bar_ax.set_xticks(x)
            self.bar_ax.set_xticklabels(months, fontname=FONT_FAMILY)
            self.bar_ax.legend(prop={"family": FONT_FAMILY})
        self.bar_fig.tight_layout(); self.bar_cv.draw()

        # Update Pie Chart
        self.pie_ax.clear()
        self.pie_ax.set_facecolor(PANEL)
        cats = {}
        for r in rows:
            if r["type"] == "Expense":
                cats[r["cat"]] = cats.get(r["cat"], 0) + r["amount"]
        if cats:
            self.pie_ax.pie(cats.values(), labels=cats.keys(), colors=[BRIGHT_BROWN, YELLOW, "#8b6a45", "#d9c77a"], autopct="%1.0f%%", textprops={'fontname': FONT_FAMILY})
        self.pie_fig.tight_layout(); self.pie_cv.draw()

if __name__ == "__main__":
    App().mainloop()